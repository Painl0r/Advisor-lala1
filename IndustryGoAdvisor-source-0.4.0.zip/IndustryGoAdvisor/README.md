# Industry GO Berater – Android-App 0.4

Lokale Android-App für Painlor. Sie vergleicht neue Minen und die erfassten Fabrik-Upgrades nach zusätzlichem Gewinn pro Stunde und Amortisationszeit.

## Enthalten

- Alle im Chat erfassten Maximaloutputs der Minen.
- Minenbaupreise.
- Die 16 erfassten Fabrik-Upgrades.
- KI-Marktpreise als editierbare Startwerte.
- Marktsteuer, standardmäßig 11 %.
- Lokale Screenshot-Auswahl über den Android Photo Picker.
- Offline-OCR mit dem gebündelten ML-Kit-Modell.
- Automatische Übernahme von Kontostand, Marktsteuer und bekannten Marktpreisen, soweit eindeutig erkannt.
- Filter auf aktuell bezahlbare Projekte.

## Rechenannahmen

Die Minenoutputs sind Endwerte inklusive:

- 100 % Qualität
- 100 % Leben
- Optimierung 5.000/5.000 beziehungsweise ×5
- Kraftwerksbonus +40 %
- Verbundsbonus ×2

Die Boni werden nicht erneut multipliziert.

Der Diamantwert wurde von 3.691/h bei 99 % Qualität linear auf 3.728/h bei 100 % hochgerechnet.

## Einschränkungen der ersten Version

- Sondierungskosten und Strombedarf einzelner Neubauten fehlen, da diese Werte noch nicht vorliegen.
- Spielergebote werden noch nicht getrennt vom KI-Markt gespeichert.
- OCR kann Punkte und Kommas verwechseln. Übernommene Werte müssen kontrolliert werden.
- Das Projekt wurde in dieser Umgebung als Quellprojekt erzeugt, aber nicht auf einem Android-Gerät getestet.

## Öffnen und APK bauen

1. ZIP entpacken.
2. Ordner in Android Studio öffnen.
3. Gradle-Synchronisierung abwarten.
4. `Build > Build APK(s)` auswählen.
5. Die Debug-APK liegt anschließend normalerweise unter `app/build/outputs/apk/debug/app-debug.apk`.

Android Studio sollte JDK 17 für Gradle verwenden.

## Version 0.2.0

- Minen-Baukosten werden aus dem Bauen-/Helikopter-Sondierung-Screenshot per OCR erkannt.
- Erkannte Kosten werden lokal gespeichert und direkt für ROI und Bezahlbarkeit verwendet.
- Alle Minenkosten können im Tab **Daten** kontrolliert und manuell korrigiert werden.


## Version 0.3.0

- Fabrik-Upgrade-Screenshots werden per OCR ausgewertet.
- Erkannt werden Fabrikname, Level vorher/nachher, Upgrade-Kosten, Dauer je Start, Produktion vorher/nachher und Rohstoffbedarf vorher/nachher.
- Die daraus berechneten Mehrmengen und Mehrverbräuche werden lokal gespeichert und sofort in der Rangliste berücksichtigt.
- Bei einem Screenshot ohne geöffnete Details werden sichere Kosten/Level übernommen. Fehlen für ein neues Level Produktionsdaten, wird das Upgrade nicht mit alten Werten schön gerechnet, sondern als unvollständig markiert.
- Fabrik-Upgradekosten können im Tab **Daten** kontrolliert und manuell korrigiert werden.


## Version 0.4.0

- Minen-Baukosten werden nicht mehr nur aus der linearen OCR-Textreihenfolge gelesen.
- Die App nutzt jetzt die Positionen der OCR-Textfelder und ordnet den rechts stehenden IC-Betrag über die gemeinsame Zeilenhöhe dem links stehenden Minennamen zu.
- Dadurch funktionieren auch Screenshots, bei denen ML Kit zuerst die komplette Namensspalte und danach die komplette Preisspalte ausgibt.
- Typische OCR-Verwechslungen in großen Zahlen, etwa `O/0`, `I/1`, `S/5` und `B/8`, werden innerhalb von Baukosten korrigiert.
- Der Status zeigt an, wie viele der 12 Minenkosten erkannt und wie viele Werte tatsächlich aktualisiert wurden. Fehlende Minen werden namentlich aufgeführt.
