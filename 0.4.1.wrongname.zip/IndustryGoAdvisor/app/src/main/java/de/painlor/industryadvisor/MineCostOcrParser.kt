package de.painlor.industryadvisor

import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

/**
 * Ein Textfragment aus ML Kit samt Position im Screenshot.
 *
 * [granularity] ist 0 für ein einzelnes OCR-Element und 1 für eine ganze OCR-Zeile.
 * Elemente werden bei gleicher Erkennung bevorzugt, weil ihre Box genauer ist.
 */
internal data class OcrBox(
    val text: String,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
    val granularity: Int
) {
    val width: Int get() = (right - left).coerceAtLeast(1)
    val height: Int get() = (bottom - top).coerceAtLeast(1)
    val centerX: Double get() = (left + right) / 2.0
    val centerY: Double get() = (top + bottom) / 2.0
    val area: Long get() = width.toLong() * height.toLong()
}

private data class MineLabelCandidate(
    val mineIndex: Int,
    val box: OcrBox,
    val aliasLength: Int,
    val extraCharacters: Int
)

private data class NumberCandidate(
    val value: Long,
    val box: OcrBox
)

/**
 * Ordnet die rechts stehenden IC-Beträge anhand ihrer vertikalen Position den
 * links stehenden Minennamen zu. Das ist zuverlässiger als die Reihenfolge in
 * result.text, weil ML Kit die zwei Spalten oft blockweise statt zeilenweise ausgibt.
 *
 * Falls ein sehr kurzer Name wie „Öl“ komplett fehlt oder als Symbolmischung erkannt
 * wird, darf genau die Lücke zwischen zwei sicher erkannten Nachbarzeilen anhand der
 * festen Minenreihenfolge ergänzt werden. Der Preis muss dabei in derselben rechts
 * ausgerichteten Zahlenspalte und an der erwarteten Zeilenposition liegen.
 */
internal fun findMineCostUpdatesFromLayout(
    boxes: List<OcrBox>,
    mineAliases: List<List<String>>
): Map<Int, Long> {
    if (boxes.isEmpty() || mineAliases.isEmpty()) return emptyMap()

    val labels = mineAliases.mapIndexedNotNull { mineIndex, aliases ->
        boxes.asSequence()
            .mapNotNull { box ->
                val boxText = canonicalMineOcr(box.text)
                aliases.asSequence()
                    .map(::canonicalMineOcr)
                    .filter { alias ->
                        alias.isNotBlank() && when {
                            alias.length <= 3 -> boxText == alias ||
                                (boxText.startsWith(alias) &&
                                    boxText.drop(alias.length).all { it.isDigit() || it in "oilsbic" })
                            else -> boxText.contains(alias)
                        }
                    }
                    .maxByOrNull { it.length }
                    ?.let { alias ->
                        MineLabelCandidate(
                            mineIndex = mineIndex,
                            box = box,
                            aliasLength = alias.length,
                            extraCharacters = (boxText.length - alias.length).coerceAtLeast(0)
                        )
                    }
            }
            .minWithOrNull(
                compareBy<MineLabelCandidate> { it.extraCharacters }
                    .thenBy { it.box.granularity }
                    .thenBy { it.box.area }
                    .thenByDescending { it.aliasLength }
            )
    }

    if (labels.isEmpty()) return emptyMap()

    val numbers = deduplicateNumberCandidates(
        boxes.flatMap { box ->
            extractBuildCostNumbers(box.text).map { value -> NumberCandidate(value, box) }
        }
    )

    if (numbers.isEmpty()) return emptyMap()

    val result = mutableMapOf<Int, Long>()
    val usedNumbers = mutableSetOf<Int>()
    val numberByMine = mutableMapOf<Int, Int>()

    labels.sortedBy { it.box.centerY }.forEach { label ->
        // Manche OCR-Versionen liefern Name und Betrag bereits als gemeinsame Zeile.
        extractBuildCostNumbers(label.box.text)
            .lastOrNull()
            ?.let { directValue ->
                result[label.mineIndex] = directValue
                numbers.indices
                    .asSequence()
                    .filterNot(usedNumbers::contains)
                    .filter { numberIndex ->
                        val candidate = numbers[numberIndex]
                        candidate.value == directValue && sameVisualRow(candidate.box, label.box)
                    }
                    .minWithOrNull(
                        compareBy<Int> { numbers[it].box.granularity }
                            .thenBy { numbers[it].box.area }
                    )
                    ?.let { numberIndex ->
                        usedNumbers += numberIndex
                        numberByMine[label.mineIndex] = numberIndex
                    }
                return@forEach
            }

        val best = numbers.indices
            .asSequence()
            .filterNot(usedNumbers::contains)
            .mapNotNull { numberIndex ->
                val number = numbers[numberIndex]
                val rowHeight = max(label.box.height, number.box.height).toDouble()
                val verticalDistance = abs(number.box.centerY - label.box.centerY)
                val allowedVerticalDistance = max(24.0, rowHeight * 1.35)
                val isOnRight = number.box.centerX >
                    label.box.centerX + max(12.0, label.box.width * 0.18)

                if (!isOnRight || verticalDistance > allowedVerticalDistance) return@mapNotNull null

                val overlapPenalty = (label.box.right - number.box.left).coerceAtLeast(0) * 3.0
                val linePenalty = if (number.box.granularity == 0) 0.0 else 4.0
                val score = verticalDistance * 10.0 + overlapPenalty + linePenalty
                numberIndex to score
            }
            .minByOrNull { it.second }
            ?.first

        if (best != null) {
            usedNumbers += best
            numberByMine[label.mineIndex] = best
            result[label.mineIndex] = numbers[best].value
        }
    }

    inferMissingRowsBetweenKnownMines(
        mineCount = mineAliases.size,
        result = result,
        numberByMine = numberByMine,
        usedNumbers = usedNumbers,
        numbers = numbers
    )

    return result
}

/**
 * Ergänzt ausschließlich innere Lücken. Beispiel: Kupfer (Index 4) und Silber
 * (Index 6) sind sicher erkannt, dazwischen steht genau ein unbenutzter Betrag in
 * derselben Zahlenspalte. Dann gehört dieser Betrag zur Öl-Zeile (Index 5).
 */
private fun inferMissingRowsBetweenKnownMines(
    mineCount: Int,
    result: MutableMap<Int, Long>,
    numberByMine: MutableMap<Int, Int>,
    usedNumbers: MutableSet<Int>,
    numbers: List<NumberCandidate>
) {
    if (numberByMine.size < 2 || result.size >= mineCount) return

    val assignedNumbers = numberByMine.values.map { numbers[it] }
    val typicalRight = median(assignedNumbers.map { it.box.right.toDouble() })
    val typicalWidth = median(assignedNumbers.map { it.box.width.toDouble() })
    val rightTolerance = max(60.0, typicalWidth * 1.15)

    // Ein Durchlauf reicht für die übliche einzelne Öl-Lücke. Mehrere unabhängige
    // Lücken werden ebenfalls verarbeitet, solange sie von sicheren Zeilen begrenzt sind.
    val knownMineIndices = numberByMine.keys.sorted()
    knownMineIndices.zipWithNext().forEach { (previousMine, nextMine) ->
        val missingCount = nextMine - previousMine - 1
        if (missingCount <= 0) return@forEach

        val previousNumber = numbers[numberByMine.getValue(previousMine)]
        val nextNumber = numbers[numberByMine.getValue(nextMine)]
        val previousY = previousNumber.box.centerY
        val nextY = nextNumber.box.centerY
        if (nextY <= previousY) return@forEach

        val rowStep = (nextY - previousY) / (nextMine - previousMine).toDouble()
        if (rowStep < 18.0) return@forEach
        val allowedVerticalDistance = max(24.0, rowStep * 0.48)

        for (mineIndex in (previousMine + 1) until nextMine) {
            if (mineIndex !in 0 until mineCount || result.containsKey(mineIndex)) continue

            val expectedY = previousY + rowStep * (mineIndex - previousMine)
            val candidateIndex = numbers.indices
                .asSequence()
                .filterNot(usedNumbers::contains)
                .filter { numberIndex ->
                    val box = numbers[numberIndex].box
                    box.centerY > previousY && box.centerY < nextY &&
                        abs(box.right - typicalRight) <= rightTolerance &&
                        abs(box.centerY - expectedY) <= allowedVerticalDistance
                }
                .minByOrNull { numberIndex ->
                    val box = numbers[numberIndex].box
                    abs(box.centerY - expectedY) * 10.0 +
                        abs(box.right - typicalRight) +
                        if (box.granularity == 0) 0.0 else 4.0
                }

            if (candidateIndex != null) {
                usedNumbers += candidateIndex
                numberByMine[mineIndex] = candidateIndex
                result[mineIndex] = numbers[candidateIndex].value
            }
        }
    }
}

private fun median(values: List<Double>): Double {
    if (values.isEmpty()) return 0.0
    val sorted = values.sorted()
    val middle = sorted.size / 2
    return if (sorted.size % 2 == 0) {
        (sorted[middle - 1] + sorted[middle]) / 2.0
    } else {
        sorted[middle]
    }
}

private fun deduplicateNumberCandidates(candidates: List<NumberCandidate>): List<NumberCandidate> {
    val result = mutableListOf<NumberCandidate>()
    candidates
        .sortedWith(
            compareBy<NumberCandidate> { it.box.granularity }
                .thenBy { it.box.area }
        )
        .forEach { candidate ->
            val duplicate = result.any { existing ->
                existing.value == candidate.value &&
                    abs(existing.box.centerY - candidate.box.centerY) <=
                    max(existing.box.height, candidate.box.height) * 0.65 &&
                    abs(existing.box.centerX - candidate.box.centerX) <=
                    max(existing.box.width, candidate.box.width) * 0.75
            }
            if (!duplicate) result += candidate
        }
    return result
}

private fun sameVisualRow(first: OcrBox, second: OcrBox): Boolean {
    val allowed = max(24.0, max(first.height, second.height) * 1.35)
    return abs(first.centerY - second.centerY) <= allowed
}

/** Erkennt auch typische OCR-Verwechslungen innerhalb großer IC-Beträge. */
private fun extractBuildCostNumbers(text: String): List<Long> {
    val groupedOrLongNumber = Regex(
        "(?<![\\p{L}\\p{N}])(?:[0-9OoIiLl|SsBb]{1,3}(?:[.,·'’\\s][0-9OoIiLl|SsBb]{3})+|[0-9OoIiLl|SsBb]{6,12})(?![\\p{L}\\p{N}])"
    )

    return groupedOrLongNumber.findAll(text)
        .mapNotNull { match ->
            val normalized = buildString {
                match.value.forEach { character ->
                    when (character) {
                        in '0'..'9' -> append(character)
                        'O', 'o' -> append('0')
                        'I', 'i', 'l', '|' -> append('1')
                        'S', 's' -> append('5')
                        'B', 'b' -> append('8')
                    }
                }
            }
            normalized.toLongOrNull()
        }
        .filter { it in 10_000L..999_999_999_999L }
        .toList()
}

private fun canonicalMineOcr(value: String): String = value
    .lowercase(Locale.GERMANY)
    .replace("ä", "ae")
    .replace("ö", "oe")
    .replace("ü", "ue")
    .replace("ß", "ss")
    .filter { it.isLetterOrDigit() }
