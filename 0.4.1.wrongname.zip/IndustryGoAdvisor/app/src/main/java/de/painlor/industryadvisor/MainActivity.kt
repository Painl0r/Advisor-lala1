package de.painlor.industryadvisor

import android.content.Context
import android.content.SharedPreferences
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ImageSearch
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.Text as MlKitText
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.max

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                IndustryAdvisorApp(applicationContext)
            }
        }
    }
}

enum class ProjectType { MINE, FACTORY }

data class MineSpec(
    val name: String,
    val defaultBuildCost: Long,
    val maxOutputPerHour: Double,
    val productKey: String,
    val ocrAliases: List<String>
)

data class InputDelta(val key: String, val amountPerStart: Double)

data class FactoryUpgrade(
    val name: String,
    val fromLevel: Int,
    val toLevel: Int,
    val cost: Long,
    val durationSeconds: Int,
    val outputKey: String,
    val outputDeltaPerStart: Double,
    val inputs: List<InputDelta>,
    val complete: Boolean = true
)

data class Recommendation(
    val type: ProjectType,
    val name: String,
    val cost: Long,
    val profitPerHour: Double,
    val paybackHours: Double,
    val affordable: Boolean,
    val note: String = ""
)

data class PriceEntry(val key: String, val label: String, val defaultValue: Double)

private val priceEntries = listOf(
    PriceEntry("clay", "Lehm", 1.03),
    PriceEntry("stone", "Stein", 2.48),
    PriceEntry("iron", "Eisen", 6.23),
    PriceEntry("coal", "Kohle", 7.09),
    PriceEntry("copper", "Kupfer", 15.15),
    PriceEntry("oil", "Öl", 26.50),
    PriceEntry("silver", "Silber", 44.00),
    PriceEntry("gold", "Gold", 88.00),
    PriceEntry("titanium", "Titan", 144.00),
    PriceEntry("diamond", "Diamant", 280.00),
    PriceEntry("rareEarth", "Seltene Erden", 336.01),
    PriceEntry("uranium", "Uran", 480.00),
    PriceEntry("brick", "Ziegel", 14.00),
    PriceEntry("concrete", "Beton", 25.24),
    PriceEntry("steel", "Stahl", 95.84),
    PriceEntry("fuel", "Treibstoff", 65.49),
    PriceEntry("plastic", "Kunststoff", 38.50),
    PriceEntry("tools", "Werkzeuge", 69.92),
    PriceEntry("machine", "Maschine", 1193.67),
    PriceEntry("electronics", "Elektronik", 214.14),
    PriceEntry("cable", "Kabel", 66.96),
    PriceEntry("sensors", "Sensoren", 1006.30),
    PriceEntry("lubricant", "Schmierstoff", 37.28),
    PriceEntry("magnets", "Magneten", 427.19),
    PriceEntry("drillHeads", "Bohrköpfe", 1383.11),
    PriceEntry("fuelRods", "Brennstäbe", 1745.91),
    PriceEntry("helicopter", "Helikopter", 4087.27),
    PriceEntry("garbageTruck", "Müllwagen", 352.12)
)

private val mines = listOf(
    MineSpec("Lehmmine", 1_014_585, 19_453.0, "clay", listOf("Lehm", "Lehmmine")),
    MineSpec("Steinmine", 226_260, 14_589.0, "stone", listOf("Stein", "Steinmine")),
    MineSpec("Eisenmine", 4_317_615, 14_589.0, "iron", listOf("Eisen", "Eisenmine")),
    MineSpec("Kohlemine", 6_267_660, 12_968.0, "coal", listOf("Kohle", "Kohlemine")),
    MineSpec("Kupfermine", 2_257_560, 14_589.0, "copper", listOf("Kupfer", "Kupfermine")),
    MineSpec(
        "Ölquelle",
        3_320_160,
        12_968.0,
        "oil",
        listOf(
            "Öl", "Ol", "Oel", "Oil",
            // ML Kit verwechselt das kleine l auf dunklem Hintergrund häufig mit I oder 1.
            "ÖI", "OI", "Ö1", "O1", "0l", "0I", "01",
            "Ölquelle", "Oelquelle", "Olquelle", "Oilquelle"
        )
    ),
    MineSpec("Silbermine", 21_013_860, 8_916.0, "silver", listOf("Silber", "Silbermine")),
    MineSpec("Goldmine", 25_824_960, 8_105.0, "gold", listOf("Gold", "Goldmine")),
    MineSpec("Titanmine", 27_450_060, 6_484.0, "titanium", listOf("Titan", "Titanmine")),
    MineSpec("Diamantmine", 60_900_000, 3_728.0, "diamond", listOf("Diamant", "Diamantmine")),
    MineSpec("Mine für Seltene Erden", 183_230_640, 3_242.0, "rareEarth", listOf("Seltene Erden", "Mine für Seltene Erden")),
    MineSpec("Uranmine", 315_906_735, 3_242.0, "uranium", listOf("Uran", "Uranmine"))
)

private val defaultFactoryUpgrades = listOf(
    FactoryUpgrade("Ziegelei", 78, 79, 19_644_374, 60, "brick", 514.0, listOf(InputDelta("clay", 1029.0))),
    FactoryUpgrade("Betonfabrik", 76, 77, 16_173_208, 90, "concrete", 343.0, listOf(InputDelta("stone", 687.0), InputDelta("clay", 343.0))),
    FactoryUpgrade("Stahlwerk", 100, 101, 416_908_018, 120, "steel", 1516.0, listOf(InputDelta("iron", 4548.0), InputDelta("coal", 3032.0))),
    FactoryUpgrade("Raffinerie", 84, 85, 35_201_746, 90, "fuel", 533.0, listOf(InputDelta("oil", 888.0))),
    FactoryUpgrade("Kabelfabrik", 92, 93, 76_618_249, 160, "cable", 1100.0, listOf(InputDelta("copper", 1467.0))),
    FactoryUpgrade("Kunststoffwerk", 54, 55, 1_905_172, 120, "plastic", 47.0, listOf(InputDelta("oil", 35.0), InputDelta("coal", 23.0))),
    FactoryUpgrade("Schmierstoffraffinerie", 58, 59, 2_810_724, 120, "lubricant", 50.0, listOf(InputDelta("oil", 67.0))),
    FactoryUpgrade("Werkzeugfabrik", 82, 83, 57_963_178, 180, "tools", 296.0, listOf(InputDelta("iron", 888.0), InputDelta("steel", 148.0))),
    FactoryUpgrade("Elektronikfabrik", 77, 78, 142_595_943, 240, "electronics", 188.0, listOf(InputDelta("copper", 564.0), InputDelta("silver", 188.0), InputDelta("gold", 94.0))),
    FactoryUpgrade("Sensorfabrik", 60, 61, 40_967_682, 300, "sensors", 20.0, listOf(InputDelta("electronics", 40.0), InputDelta("rareEarth", 20.0))),
    FactoryUpgrade("Magnetfabrik", 52, 53, 9_411_165, 300, "magnets", 20.0, listOf(InputDelta("iron", 78.0), InputDelta("rareEarth", 20.0))),
    FactoryUpgrade("Bohrkopffabrik", 93, 94, 1_688_819_434, 420, "drillHeads", 402.0, listOf(InputDelta("titanium", 1205.0), InputDelta("diamond", 402.0), InputDelta("steel", 803.0))),
    FactoryUpgrade("Maschinenfabrik", 86, 87, 213_784_498, 240, "machine", 213.0, listOf(InputDelta("steel", 851.0), InputDelta("cable", 851.0), InputDelta("fuel", 426.0))),
    FactoryUpgrade("Brennstäbe-Fabrik", 62, 63, 186_601_299, 480, "fuelRods", 24.0, listOf(InputDelta("uranium", 48.0), InputDelta("steel", 73.0))),
    FactoryUpgrade("Helikopterwerk", 19, 20, 3_804_962, 900, "helicopter", 0.0, listOf(InputDelta("steel", 3.0), InputDelta("machine", 1.0), InputDelta("cable", 2.0), InputDelta("fuel", 1.0))),
    FactoryUpgrade("Müllwagenwerk", 37, 38, 3_284_124, 600, "garbageTruck", 2.0, listOf(InputDelta("steel", 2.0), InputDelta("cable", 2.0), InputDelta("fuel", 2.0), InputDelta("lubricant", 2.0), InputDelta("tools", 2.0)))
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IndustryAdvisorApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("industry_go_advisor", Context.MODE_PRIVATE) }
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var cashText by rememberSaveable { mutableStateOf(prefs.getLong("cash", 46_705_712L).toString()) }
    var taxText by rememberSaveable { mutableStateOf(prefs.getFloat("tax", 11f).toString().replace('.', ',')) }
    var affordableOnly by rememberSaveable { mutableStateOf(true) }
    var ocrText by rememberSaveable { mutableStateOf("") }
    var ocrStatus by rememberSaveable { mutableStateOf("Noch kein Screenshot eingelesen.") }
    var isOcrRunning by remember { mutableStateOf(false) }

    val priceValues = remember {
        mutableStateListOf<Double>().apply {
            priceEntries.forEach { entry ->
                add(java.lang.Double.longBitsToDouble(prefs.getLong("price_${entry.key}", entry.defaultValue.toBits())))
            }
        }
    }

    val mineCostValues = remember {
        mutableStateListOf<Long>().apply {
            mines.forEach { mine ->
                add(prefs.getLong("mine_cost_${mine.productKey}", mine.defaultBuildCost))
            }
        }
    }

    val factoryUpgradeValues = remember {
        mutableStateListOf<FactoryUpgrade>().apply {
            defaultFactoryUpgrades.forEachIndexed { index, upgrade ->
                add(loadFactoryUpgrade(prefs, index, upgrade))
            }
        }
    }

    fun saveSettings() {
        val cash = parseLongGerman(cashText) ?: 0L
        val tax = parseDoubleGerman(taxText) ?: 11.0
        prefs.edit().apply {
            putLong("cash", cash)
            putFloat("tax", tax.toFloat())
            priceEntries.forEachIndexed { index, entry -> putLong("price_${entry.key}", priceValues[index].toBits()) }
            mines.forEachIndexed { index, mine -> putLong("mine_cost_${mine.productKey}", mineCostValues[index]) }
            factoryUpgradeValues.forEachIndexed { index, upgrade -> saveFactoryUpgrade(this, index, upgrade) }
        }.apply()
    }

    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    fun applyParsedResult(parsed: OcrApplyResult, rawText: String) {
        cashText = parsed.cashText
        taxText = parsed.taxText
        parsed.priceUpdates.forEach { (index, value) -> priceValues[index] = value }
        parsed.mineCostUpdates.forEach { (index, value) -> mineCostValues[index] = value }
        parsed.factoryUpgradeUpdate?.let { (index, upgrade) ->
            factoryUpgradeValues[index] = upgrade
        }
        ocrText = rawText
    }

    fun buildImportSummary(
        source: String,
        processed: Int,
        priceIndices: Set<Int>,
        mineIndices: Set<Int>,
        factoryIndices: Set<Int>,
        cashUpdated: Boolean,
        taxUpdated: Boolean,
        failures: Int
    ): String {
        val parts = mutableListOf<String>()
        parts += "$source: $processed Datei-/Bildabschnitt(e) geprüft"
        if (mineIndices.isNotEmpty()) parts += "${mineIndices.size}/${mines.size} Minenkosten erkannt"
        if (priceIndices.isNotEmpty()) parts += "${priceIndices.size} Marktpreise erkannt"
        if (factoryIndices.isNotEmpty()) parts += "${factoryIndices.size} Fabrik-Upgrades erkannt"
        if (cashUpdated) parts += "Kontostand aktualisiert"
        if (taxUpdated) parts += "Marktsteuer aktualisiert"
        if (failures > 0) parts += "$failures Abschnitt(e) ohne Auswertung"
        if (parts.size == 1) parts += "keine sicheren Werte erkannt"
        return parts.joinToString(" · ") + ". Daten wurden lokal gespeichert."
    }

    fun processScreenshots(uris: List<Uri>) {
        if (uris.isEmpty()) return
        isOcrRunning = true
        ocrStatus = "Bereite ${uris.size} Screenshot(s) vor …"

        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val priceIndices = mutableSetOf<Int>()
        val mineIndices = mutableSetOf<Int>()
        val factoryIndices = mutableSetOf<Int>()
        var cashUpdated = false
        var taxUpdated = false
        var failures = 0
        var processed = 0

        fun finish() {
            saveSettings()
            recognizer.close()
            isOcrRunning = false
            ocrStatus = buildImportSummary(
                source = if (uris.size == 1) "Screenshot" else "Screenshot-Serie",
                processed = processed,
                priceIndices = priceIndices,
                mineIndices = mineIndices,
                factoryIndices = factoryIndices,
                cashUpdated = cashUpdated,
                taxUpdated = taxUpdated,
                failures = failures
            )
        }

        fun processNext(index: Int) {
            if (index >= uris.size) {
                finish()
                return
            }

            ocrStatus = "Screenshot ${index + 1}/${uris.size} wird erkannt …"
            val imageResult = runCatching { InputImage.fromFilePath(context, uris[index]) }
            if (imageResult.isFailure) {
                failures++
                processed++
                processNext(index + 1)
                return
            }
            val image = imageResult.getOrThrow()

            recognizer.process(image)
                .addOnSuccessListener { result ->
                    val beforeCash = cashText
                    val beforeTax = taxText
                    val parsed = applyOcrValues(
                        result,
                        cashText,
                        taxText,
                        mineCostValues,
                        factoryUpgradeValues
                    )
                    applyParsedResult(parsed, result.text)
                    priceIndices += parsed.priceUpdates.keys
                    mineIndices += parsed.recognizedMineCostIndices
                    parsed.factoryUpgradeUpdate?.first?.let(factoryIndices::add)
                    cashUpdated = cashUpdated || parsed.cashText != beforeCash
                    taxUpdated = taxUpdated || parsed.taxText != beforeTax
                }
                .addOnFailureListener { failures++ }
                .addOnCompleteListener {
                    processed++
                    processNext(index + 1)
                }
        }

        processNext(0)
    }

    fun processScreenRecording(uri: Uri) {
        isOcrRunning = true
        ocrStatus = "Bildschirmaufnahme wird vorbereitet …"

        Thread {
            val retriever = MediaMetadataRetriever()
            val setup = runCatching {
                retriever.setDataSource(context, uri)
                val durationMs: Long = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()
                    ?: error("Videolänge konnte nicht gelesen werden")
                val stepMs = maxOf(1_200L, (durationMs / 100L).coerceAtLeast(1L))
                val timestamps: List<Long> = buildList<Long> {
                    var timestamp = 0L
                    while (timestamp <= durationMs && size < 120) {
                        add(timestamp)
                        timestamp += stepMs
                    }
                    if (isEmpty() || last() < durationMs) add(durationMs)
                }
                timestamps
            }

            mainHandler.post outerPost@{
                val timestamps = setup.getOrElse { error ->
                    runCatching { retriever.release() }
                    isOcrRunning = false
                    ocrStatus = "Bildschirmaufnahme konnte nicht geöffnet werden: ${error.message}"
                    return@outerPost
                }

                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                val priceIndices = mutableSetOf<Int>()
                val mineIndices = mutableSetOf<Int>()
                val factoryIndices = mutableSetOf<Int>()
                var cashUpdated = false
                var taxUpdated = false
                var failures = 0
                var processed = 0

                fun finish() {
                    saveSettings()
                    recognizer.close()
                    runCatching { retriever.release() }
                    isOcrRunning = false
                    ocrStatus = buildImportSummary(
                        source = "Bildschirmaufnahme",
                        processed = processed,
                        priceIndices = priceIndices,
                        mineIndices = mineIndices,
                        factoryIndices = factoryIndices,
                        cashUpdated = cashUpdated,
                        taxUpdated = taxUpdated,
                        failures = failures
                    )
                }

                fun processFrame(index: Int) {
                    if (index >= timestamps.size) {
                        finish()
                        return
                    }

                    ocrStatus = "Bildschirmaufnahme: Abschnitt ${index + 1}/${timestamps.size} wird erkannt …"
                    val timestampUs = timestamps[index] * 1_000L

                    Thread {
                        val bitmap = runCatching {
                            retriever.getFrameAtTime(
                                timestampUs,
                                MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                            )
                        }.getOrNull()

                        mainHandler.post framePost@{
                            if (bitmap == null) {
                                failures++
                                processed++
                                processFrame(index + 1)
                                return@framePost
                            }

                            val image = InputImage.fromBitmap(bitmap, 0)
                            recognizer.process(image)
                                .addOnSuccessListener { result ->
                                    val beforeCash = cashText
                                    val beforeTax = taxText
                                    val parsed = applyOcrValues(
                                        result,
                                        cashText,
                                        taxText,
                                        mineCostValues,
                                        factoryUpgradeValues
                                    )
                                    applyParsedResult(
                                        parsed,
                                        "Letzter erkannter Videoabschnitt:\n${result.text}"
                                    )
                                    priceIndices += parsed.priceUpdates.keys
                                    mineIndices += parsed.recognizedMineCostIndices
                                    parsed.factoryUpgradeUpdate?.first?.let(factoryIndices::add)
                                    cashUpdated = cashUpdated || parsed.cashText != beforeCash
                                    taxUpdated = taxUpdated || parsed.taxText != beforeTax
                                }
                                .addOnFailureListener { failures++ }
                                .addOnCompleteListener {
                                    bitmap.recycle()
                                    processed++
                                    processFrame(index + 1)
                                }
                        }
                    }.start()
                }

                processFrame(0)
            }
        }.start()
    }

    val singleScreenshotPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let { processScreenshots(listOf(it)) }
    }

    val screenshotSeriesPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(20)
    ) { uris: List<Uri> ->
        processScreenshots(uris)
    }

    val screenRecordingPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let(::processScreenRecording)
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(title = { Text("Industry GO Berater") })
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Analytics, null) },
                    label = { Text("Analyse") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.ImageSearch, null) },
                    label = { Text("Import") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Edit, null) },
                    label = { Text("Daten") }
                )
            }
        }
    ) { padding ->
        when (selectedTab) {
            0 -> AnalysisScreen(
                modifier = Modifier.padding(padding),
                cashText = cashText,
                onCashChange = { cashText = it; saveSettings() },
                taxText = taxText,
                onTaxChange = { taxText = it; saveSettings() },
                affordableOnly = affordableOnly,
                onAffordableOnlyChange = { affordableOnly = it },
                prices = priceEntries.mapIndexed { index, entry -> entry.key to priceValues[index] }.toMap(),
                mineCosts = mines.mapIndexed { index, mine -> mine.productKey to mineCostValues[index] }.toMap(),
                factoryUpgrades = factoryUpgradeValues.toList()
            )
            1 -> ScreenshotScreen(
                modifier = Modifier.padding(padding),
                isRunning = isOcrRunning,
                status = ocrStatus,
                ocrText = ocrText,
                mineCosts = mineCostValues,
                factoryUpgrades = factoryUpgradeValues,
                onPickSingle = {
                    singleScreenshotPicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                onPickSeries = {
                    screenshotSeriesPicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                onPickVideo = {
                    screenRecordingPicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                    )
                }
            )
            else -> PricesScreen(
                modifier = Modifier.padding(padding),
                priceValues = priceValues,
                onPriceChange = { index, value ->
                    priceValues[index] = value
                    saveSettings()
                },
                mineCostValues = mineCostValues,
                onMineCostChange = { index, value ->
                    mineCostValues[index] = value
                    saveSettings()
                },
                onResetPrices = {
                    priceEntries.forEachIndexed { index, entry -> priceValues[index] = entry.defaultValue }
                    saveSettings()
                },
                onResetMineCosts = {
                    mines.forEachIndexed { index, mine -> mineCostValues[index] = mine.defaultBuildCost }
                    saveSettings()
                },
                factoryUpgrades = factoryUpgradeValues,
                onFactoryCostChange = { index, value ->
                    factoryUpgradeValues[index] = factoryUpgradeValues[index].copy(cost = value)
                    saveSettings()
                },
                onResetFactoryUpgrades = {
                    defaultFactoryUpgrades.forEachIndexed { index, upgrade -> factoryUpgradeValues[index] = upgrade }
                    saveSettings()
                }
            )
        }
    }
}

@Composable
private fun AnalysisScreen(
    modifier: Modifier,
    cashText: String,
    onCashChange: (String) -> Unit,
    taxText: String,
    onTaxChange: (String) -> Unit,
    affordableOnly: Boolean,
    onAffordableOnlyChange: (Boolean) -> Unit,
    prices: Map<String, Double>,
    mineCosts: Map<String, Long>,
    factoryUpgrades: List<FactoryUpgrade>
) {
    val cash = parseLongGerman(cashText) ?: 0L
    val taxPercent = (parseDoubleGerman(taxText) ?: 11.0).coerceIn(0.0, 99.0)
    val recommendations = remember(cash, taxPercent, prices, mineCosts, factoryUpgrades) {
        calculateRecommendations(cash, taxPercent, prices, mineCosts, factoryUpgrades)
    }
    val visible = if (affordableOnly) recommendations.filter { it.affordable } else recommendations

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            OutlinedTextField(
                value = cashText,
                onValueChange = onCashChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Verfügbares IC") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        }
        item {
            OutlinedTextField(
                value = taxText,
                onValueChange = onTaxChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Marktsteuer in %") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("Nur aktuell bezahlbare Projekte", modifier = Modifier.weight(1f))
                Switch(checked = affordableOnly, onCheckedChange = onAffordableOnlyChange)
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Rechenmodus", fontWeight = FontWeight.Bold)
                    Text("Minen: 100 % Qualität, volle Optimierung ×5, Kraftwerk +40 % und Verbund ×2 sind bereits im Maximaloutput enthalten.")
                    Text("Preise: KI-Markt. Erlöse und Rohstoff-Opportunitätskosten werden um die Marktsteuer vermindert.")
                }
            }
        }
        if (visible.isEmpty()) {
            item { Text("Kein Projekt erfüllt den Filter.") }
        } else {
            items(visible) { rec -> RecommendationCard(rec) }
        }
    }
}

@Composable
private fun RecommendationCard(rec: Recommendation) {
    val nf = NumberFormat.getNumberInstance(Locale.GERMANY).apply { maximumFractionDigits = 1 }
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(rec.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(if (rec.type == ProjectType.MINE) "MINE" else "FABRIK")
            }
            Text("Kosten: ${formatIc(rec.cost)}")
            val detailsMissing = rec.note.contains("Produktionsdetails fehlen", ignoreCase = true)
            if (detailsMissing) {
                Text("Mehrgewinn: noch nicht berechenbar")
                Text("Amortisation: Produktionsdaten fehlen", color = MaterialTheme.colorScheme.error)
            } else {
                Text("Mehrgewinn: ${formatIc(rec.profitPerHour)} /h")
                if (rec.profitPerHour > 0.0 && rec.paybackHours.isFinite()) {
                    val days = rec.paybackHours / 24.0
                    Text("Amortisation: ${nf.format(rec.paybackHours)} h (${nf.format(days)} Tage)")
                } else {
                    Text("Amortisation: nie – wirtschaftlich negativ", color = MaterialTheme.colorScheme.error)
                }
            }
            Text(if (rec.affordable) "Jetzt bezahlbar" else "Noch nicht bezahlbar")
            if (rec.note.isNotBlank()) Text(rec.note)
        }
    }
}

@Composable
private fun ScreenshotScreen(
    modifier: Modifier,
    isRunning: Boolean,
    status: String,
    ocrText: String,
    mineCosts: List<Long>,
    factoryUpgrades: List<FactoryUpgrade>,
    onPickSingle: () -> Unit,
    onPickSeries: () -> Unit,
    onPickVideo: () -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Wenig Dateien, viele Daten", fontWeight = FontWeight.Bold)
                    Text(
                        "Am bequemsten ist eine Bildschirmaufnahme. Öffne darin nacheinander " +
                            "die Minenliste, die Marktseiten und nur die benötigten Fabrik-Details. " +
                            "Bleibe auf jedem wichtigen Fenster ungefähr 2 Sekunden stehen."
                    )
                }
            }
        }
        item {
            Button(onClick = onPickVideo, enabled = !isRunning, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.VideoLibrary, null)
                Spacer(Modifier.padding(4.dp))
                Text(if (isRunning) "Wird erkannt …" else "1 Bildschirmaufnahme auswählen")
            }
        }
        item {
            Button(onClick = onPickSeries, enabled = !isRunning, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Collections, null)
                Spacer(Modifier.padding(4.dp))
                Text("Mehrere Screenshots auf einmal auswählen")
            }
        }
        item {
            Button(onClick = onPickSingle, enabled = !isRunning, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.ImageSearch, null)
                Spacer(Modifier.padding(4.dp))
                Text("Einzelnen Screenshot auswählen")
            }
        }
        item {
            Card {
                Column(Modifier.padding(14.dp)) {
                    Text("Status", fontWeight = FontWeight.Bold)
                    Text(status)
                }
            }
        }
        item {
            Text("Erkannter Text", fontWeight = FontWeight.Bold)
            Card(modifier = Modifier.fillMaxWidth()) {
                Text(
                    if (ocrText.isBlank()) "Noch keine OCR-Ausgabe." else ocrText,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
        item {
            Text("Gespeicherte Minen-Baukosten", fontWeight = FontWeight.Bold)
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    mines.forEachIndexed { index, mine ->
                        Row(Modifier.fillMaxWidth()) {
                            Text(mine.name, modifier = Modifier.weight(1f))
                            Text(formatIc(mineCosts[index]))
                        }
                    }
                }
            }
        }
        item {
            Text("Gespeicherte Fabrik-Upgrades", fontWeight = FontWeight.Bold)
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    factoryUpgrades.forEach { upgrade ->
                        Column {
                            Text("${upgrade.name} L${upgrade.fromLevel} → L${upgrade.toLevel}", fontWeight = FontWeight.Bold)
                            Text("Kosten: ${formatIc(upgrade.cost)}")
                            Text(
                                if (upgrade.complete) {
                                    "Mehrproduktion ${formatAmount(upgrade.outputDeltaPerStart)} je Start · ${formatDuration(upgrade.durationSeconds)}"
                                } else {
                                    "Produktionsdetails fehlen – Details-Screenshot hochladen."
                                }
                            )
                        }
                    }
                }
            }
        }
        item {
            Text(
                "Alles wird ausschließlich auf dem Handy ausgewertet; Bilder und Videos werden " +
                    "nicht an einen Server gesendet. Ein Minenlisten-Bild reicht für alle zwölf " +
                    "Minenkosten. Lange beziehungsweise scrollende Screenshots werden ebenfalls " +
                    "verarbeitet. Bei Fabriken brauchst du nur Fenster aufzunehmen, deren Level " +
                    "oder Kosten sich geändert haben oder deren Produktionsdetails noch fehlen."
            )
        }
    }
}

@Composable
private fun PricesScreen(
    modifier: Modifier,
    priceValues: List<Double>,
    onPriceChange: (Int, Double) -> Unit,
    mineCostValues: List<Long>,
    onMineCostChange: (Int, Long) -> Unit,
    onResetPrices: () -> Unit,
    onResetMineCosts: () -> Unit,
    factoryUpgrades: List<FactoryUpgrade>,
    onFactoryCostChange: (Int, Long) -> Unit,
    onResetFactoryUpgrades: () -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { Text("Minen-Baukosten", fontWeight = FontWeight.Bold) }
        item {
            Button(onClick = onResetMineCosts, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Refresh, null)
                Spacer(Modifier.padding(4.dp))
                Text("Minenkosten auf Ausgangswerte setzen")
            }
        }
        items(mines.indices.toList()) { index ->
            var text by remember(mineCostValues[index]) { mutableStateOf(mineCostValues[index].toString()) }
            OutlinedTextField(
                value = text,
                onValueChange = { input ->
                    text = input
                    parseLongGerman(input)?.let { if (it >= 0) onMineCostChange(index, it) }
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("${mines[index].name} – Baukosten") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        }
        item {
            Spacer(Modifier.height(8.dp))
            HorizontalDivider()
            Spacer(Modifier.height(8.dp))
            Text("Fabrik-Upgrades", fontWeight = FontWeight.Bold)
        }
        item {
            Button(onClick = onResetFactoryUpgrades, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Refresh, null)
                Spacer(Modifier.padding(4.dp))
                Text("Fabrik-Upgrades auf Ausgangswerte setzen")
            }
        }
        items(factoryUpgrades.indices.toList()) { index ->
            val upgrade = factoryUpgrades[index]
            var text by remember(upgrade.cost) { mutableStateOf(upgrade.cost.toString()) }
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { input ->
                        text = input
                        parseLongGerman(input)?.let { if (it >= 0) onFactoryCostChange(index, it) }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("${upgrade.name} L${upgrade.fromLevel} → L${upgrade.toLevel} – Kosten") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Text(
                    if (upgrade.complete) {
                        "Mehrproduktion ${formatAmount(upgrade.outputDeltaPerStart)} je Start · ${formatDuration(upgrade.durationSeconds)} · ${upgrade.inputs.size} zusätzliche Rohstoffe"
                    } else {
                        "Produktionsdetails fehlen. Screenshot mit geöffneten Details hochladen."
                    },
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        item {
            Spacer(Modifier.height(8.dp))
            HorizontalDivider()
            Spacer(Modifier.height(8.dp))
            Text("KI-Marktpreise", fontWeight = FontWeight.Bold)
        }
        item {
            Button(onClick = onResetPrices, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Refresh, null)
                Spacer(Modifier.padding(4.dp))
                Text("KI-Preise zurücksetzen")
            }
        }
        items(priceEntries.indices.toList()) { index ->
            var text by remember(priceValues[index]) { mutableStateOf(formatDecimal(priceValues[index])) }
            OutlinedTextField(
                value = text,
                onValueChange = { input ->
                    text = input
                    parseDoubleGerman(input)?.let { if (it >= 0) onPriceChange(index, it) }
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("${priceEntries[index].label} – IC/Stk") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
        }
    }
}

private fun calculateRecommendations(
    cash: Long,
    taxPercent: Double,
    prices: Map<String, Double>,
    mineCosts: Map<String, Long>,
    factoryUpgrades: List<FactoryUpgrade>
): List<Recommendation> {
    val netFactor = 1.0 - taxPercent / 100.0
    val mineRecommendations = mines.map { mine ->
        val price = prices[mine.productKey] ?: 0.0
        val cost = mineCosts[mine.productKey] ?: mine.defaultBuildCost
        val profit = mine.maxOutputPerHour * price * netFactor
        Recommendation(
            type = ProjectType.MINE,
            name = mine.name,
            cost = cost,
            profitPerHour = profit,
            paybackHours = if (profit > 0) cost / profit else Double.POSITIVE_INFINITY,
            affordable = cash >= cost,
            note = "Idealoutput ${formatAmount(mine.maxOutputPerHour)}/h"
        )
    }

    val factoryRecommendations = factoryUpgrades.map { upgrade ->
        if (!upgrade.complete || upgrade.durationSeconds <= 0) {
            Recommendation(
                type = ProjectType.FACTORY,
                name = "${upgrade.name} L${upgrade.fromLevel} → L${upgrade.toLevel}",
                cost = upgrade.cost,
                profitPerHour = 0.0,
                paybackHours = Double.POSITIVE_INFINITY,
                affordable = cash >= upgrade.cost,
                note = "Kosten erkannt, aber Produktionsdetails fehlen. Upgrade-Fenster mit geöffneten Details hochladen."
            )
        } else {
            val startsPerHour = 3600.0 / upgrade.durationSeconds
            val grossOutput = upgrade.outputDeltaPerStart * startsPerHour * (prices[upgrade.outputKey] ?: 0.0)
            val grossInputs = upgrade.inputs.sumOf { input ->
                input.amountPerStart * startsPerHour * (prices[input.key] ?: 0.0)
            }
            val profit = (grossOutput - grossInputs) * netFactor
            Recommendation(
                type = ProjectType.FACTORY,
                name = "${upgrade.name} L${upgrade.fromLevel} → L${upgrade.toLevel}",
                cost = upgrade.cost,
                profitPerHour = profit,
                paybackHours = if (profit > 0) upgrade.cost / profit else Double.POSITIVE_INFINITY,
                affordable = cash >= upgrade.cost,
                note = if (upgrade.outputDeltaPerStart <= 0) "Kein zusätzlicher Output, aber höherer Verbrauch." else ""
            )
        }
    }

    return (mineRecommendations + factoryRecommendations).sortedWith(
        compareBy<Recommendation> { if (it.profitPerHour > 0) it.paybackHours else Double.POSITIVE_INFINITY }
            .thenByDescending { it.profitPerHour }
    )
}

private data class OcrApplyResult(
    val cashText: String,
    val taxText: String,
    val priceUpdates: Map<Int, Double>,
    val mineCostUpdates: Map<Int, Long>,
    val recognizedMineCostIndices: Set<Int>,
    val factoryUpgradeUpdate: Pair<Int, FactoryUpgrade>?,
    val message: String
)

private data class ParsedFactoryUpgrade(
    val index: Int,
    val upgrade: FactoryUpgrade,
    val message: String
)

private fun applyOcrValues(
    ocrResult: MlKitText,
    oldCash: String,
    oldTax: String,
    oldMineCosts: List<Long>,
    oldFactoryUpgrades: List<FactoryUpgrade>
): OcrApplyResult {
    val text = ocrResult.text
    var cash = oldCash
    var tax = oldTax
    val updates = mutableMapOf<Int, Double>()
    val mineCostUpdates = mutableMapOf<Int, Long>()
    val normalized = text
        .replace('\u00A0', ' ')
        .replace(Regex("[ \t]+"), " ")

    Regex("Du\\s+hast\\s+([0-9.\\s]+)", RegexOption.IGNORE_CASE)
        .find(normalized)
        ?.groupValues
        ?.getOrNull(1)
        ?.let { parseLongGerman(it) }
        ?.let { cash = it.toString() }

    if (cash == oldCash) {
        Regex("(?m)^([0-9]{1,3}(?:\\.[0-9]{3}){2,})\\s*(?:IC)?$")
            .find(normalized)
            ?.groupValues
            ?.getOrNull(1)
            ?.let { parseLongGerman(it) }
            ?.let { cash = it.toString() }
    }

    Regex("L11[^%]{0,40}(11)%", RegexOption.IGNORE_CASE).find(normalized)?.let { tax = "11" }
    Regex("Marktsteuer\\s*(?:ca\\.)?\\s*([0-9]{1,2})%", RegexOption.IGNORE_CASE)
        .find(normalized)
        ?.groupValues
        ?.getOrNull(1)
        ?.let { tax = it }

    priceEntries.forEachIndexed { index, entry ->
        val escaped = Regex.escape(entry.label)
        val pattern = Regex(
            "$escaped[\\s\\S]{0,90}?([0-9]{1,4}(?:[.,][0-9]{1,2})?)\\s*(?:IC)?\\s*/?Stk",
            RegexOption.IGNORE_CASE
        )
        pattern.find(normalized)?.groupValues?.getOrNull(1)?.let { raw ->
            parseDoubleGerman(raw)?.let { value ->
                if (value > 0) updates[index] = value
            }
        }
    }

    val hasMineBuildContext = Regex(
        "Helikopter[-\\s]?Sondierung|\\bBauen\\b|Mine\\s+bauen|Minenbau",
        RegexOption.IGNORE_CASE
    ).containsMatchIn(normalized)
    val layoutMineCosts = findMineCostUpdatesFromLayout(
        boxes = collectOcrBoxes(ocrResult),
        mineAliases = mines.map { it.ocrAliases }
    )
    val looksLikeMineCostList = layoutMineCosts.size >= 4
    val recognizedMineCosts = if (hasMineBuildContext || looksLikeMineCostList) {
        // Text-Fallback zuerst, die positionsbasierte Zuordnung gewinnt bei Konflikten.
        findMineCostUpdatesFromText(normalized) + layoutMineCosts
    } else {
        emptyMap()
    }
    recognizedMineCosts.forEach { (index, value) ->
        if (value > 0 && value != oldMineCosts.getOrNull(index)) mineCostUpdates[index] = value
    }

    val parsedFactory = findFactoryUpgradeUpdate(normalized, oldFactoryUpgrades)

    val parts = mutableListOf<String>()
    if (cash != oldCash) parts += "Kontostand übernommen"
    if (tax != oldTax) parts += "Marktsteuer übernommen"
    if (updates.isNotEmpty()) parts += "${updates.size} Marktpreis(e) übernommen"
    if (recognizedMineCosts.isNotEmpty()) {
        parts += if (mineCostUpdates.isNotEmpty()) {
            "${recognizedMineCosts.size}/${mines.size} Minen-Baukosten erkannt, ${mineCostUpdates.size} aktualisiert"
        } else {
            "${recognizedMineCosts.size}/${mines.size} Minen-Baukosten erkannt (unverändert)"
        }
        if (recognizedMineCosts.size < mines.size) {
            val missing = mines.indices
                .filterNot(recognizedMineCosts::containsKey)
                .joinToString { mines[it].name }
            parts += "Nicht erkannt: $missing"
        }
    }
    parsedFactory?.let { parts += it.message }

    val message = if (parts.isEmpty()) {
        "Text erkannt, aber keine sicheren Werte automatisch übernommen. Bitte OCR-Text und Eingaben kontrollieren."
    } else {
        parts.joinToString(" · ") + ". Bitte kontrollieren."
    }
    return OcrApplyResult(
        cashText = cash,
        taxText = tax,
        priceUpdates = updates,
        mineCostUpdates = mineCostUpdates,
        recognizedMineCostIndices = recognizedMineCosts.keys,
        factoryUpgradeUpdate = parsedFactory?.let { it.index to it.upgrade },
        message = message
    )
}

private fun findFactoryUpgradeUpdate(
    text: String,
    oldFactoryUpgrades: List<FactoryUpgrade>
): ParsedFactoryUpgrade? {
    if (!Regex("ausbauen|Upgrade|Was\\s+verbessert\\s+sich|Kosten\\s*:", RegexOption.IGNORE_CASE)
            .containsMatchIn(text)
    ) return null

    val compactText = canonicalOcr(text)
    val index = oldFactoryUpgrades.indices
        .sortedByDescending { oldFactoryUpgrades[it].name.length }
        .firstOrNull { compactText.contains(canonicalOcr(oldFactoryUpgrades[it].name)) }
        ?: return null

    val current = oldFactoryUpgrades[index]
    val levelMatch = Regex(
        "Von\\s*L\\s*([0-9]+)\\s*auf\\s*L\\s*([0-9]+)",
        RegexOption.IGNORE_CASE
    ).find(text)
    val fromLevel = levelMatch?.groupValues?.getOrNull(1)?.toIntOrNull() ?: current.fromLevel
    val toLevel = levelMatch?.groupValues?.getOrNull(2)?.toIntOrNull() ?: current.toLevel

    val cost = Regex(
        "Kosten\\s*:?\\s*([0-9]{1,3}(?:[.\\s][0-9]{3})+|[0-9]{5,12})",
        RegexOption.IGNORE_CASE
    ).find(text)?.groupValues?.getOrNull(1)?.let(::parseLongGerman) ?: return null

    val outputValues = findOutputArrowValues(text, current.outputKey)
    val durationSeconds = findUpgradeDurationSeconds(text)
    val inputs = findInputDeltas(text, current.outputKey)
    val hasFullDetails = outputValues != null && durationSeconds != null

    val sameLevel = fromLevel == current.fromLevel && toLevel == current.toLevel
    val updated = if (hasFullDetails) {
        FactoryUpgrade(
            name = current.name,
            fromLevel = fromLevel,
            toLevel = toLevel,
            cost = cost,
            durationSeconds = durationSeconds!!,
            outputKey = current.outputKey,
            outputDeltaPerStart = max(0.0, outputValues!!.second - outputValues.first),
            inputs = inputs,
            complete = true
        )
    } else if (sameLevel && current.complete) {
        current.copy(cost = cost)
    } else {
        current.copy(
            fromLevel = fromLevel,
            toLevel = toLevel,
            cost = cost,
            durationSeconds = 0,
            outputDeltaPerStart = 0.0,
            inputs = emptyList(),
            complete = false
        )
    }

    val message = when {
        hasFullDetails ->
            "${current.name} L$fromLevel → L$toLevel vollständig übernommen"
        sameLevel && current.complete ->
            "${current.name}-Upgradekosten übernommen; vorhandene Produktionsdaten beibehalten"
        else ->
            "${current.name}-Upgradekosten übernommen; Produktionsdetails fehlen"
    }
    return ParsedFactoryUpgrade(index, updated, message)
}

private fun findOutputArrowValues(text: String, outputKey: String): Pair<Double, Double>? {
    val labels = aliasesForResource(outputKey)
    val labelPattern = labels.sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) }
    val number = "([0-9]{1,3}(?:[.\\s][0-9]{3})+|[0-9]+)"
    val arrow = "(?:→|->|›|»|➜|—>)"
    val pattern = Regex(
        "$number\\s*[x×]?\\s*(?:$labelPattern)\\s*$arrow\\s*$number\\s*[x×]?\\s*(?:$labelPattern)",
        RegexOption.IGNORE_CASE
    )
    val match = pattern.find(text.replace(Regex("\\s+"), " ")) ?: return null
    val before = parseLongGerman(match.groupValues[1])?.toDouble() ?: return null
    val after = parseLongGerman(match.groupValues[2])?.toDouble() ?: return null
    return before to after
}

private fun findInputDeltas(text: String, outputKey: String): List<InputDelta> {
    val normalized = text.replace(Regex("\\s+"), " ")
    val marker = Regex("Rohstoffbedarf", RegexOption.IGNORE_CASE).find(normalized)
    val inputArea = if (marker != null) normalized.substring(marker.range.first) else normalized
    val number = "([0-9]{1,3}(?:[.\\s][0-9]{3})+|[0-9]+)"
    val arrow = "(?:→|->|›|»|➜|—>)"

    return priceEntries
        .asSequence()
        .filter { it.key != outputKey }
        .mapNotNull { entry ->
            val labelPattern = aliasesForResource(entry.key)
                .sortedByDescending { it.length }
                .joinToString("|") { Regex.escape(it) }
            val pattern = Regex(
                "(?:$labelPattern)\\s*:?\\s*$number\\s*$arrow\\s*$number",
                RegexOption.IGNORE_CASE
            )
            val match = pattern.find(inputArea) ?: return@mapNotNull null
            val before = parseLongGerman(match.groupValues[1])?.toDouble() ?: return@mapNotNull null
            val after = parseLongGerman(match.groupValues[2])?.toDouble() ?: return@mapNotNull null
            val delta = after - before
            if (delta > 0.0) InputDelta(entry.key, delta) else null
        }
        .toList()
}

private fun findUpgradeDurationSeconds(text: String): Int? {
    val normalized = text.replace(Regex("\\s+"), " ")
    val durationStart = Regex("Dauer\\s+je\\s+Start", RegexOption.IGNORE_CASE)
        .find(normalized)
        ?.range
        ?.last
        ?.plus(1)
        ?: return null
    val rawEnd = Regex("Rohstoffbedarf|Der\\s+Server", RegexOption.IGNORE_CASE)
        .find(normalized, durationStart)
        ?.range
        ?.first
        ?: normalized.length
    val area = normalized.substring(durationStart, rawEnd)
    val token = Regex(
        "(?:(\\d+)\\s*h(?:\\s*(\\d+)\\s*m)?(?:\\s*(\\d+)\\s*s)?|(\\d+)\\s*m(?:\\s*(\\d+)\\s*s)?|(\\d+)\\s*s)",
        RegexOption.IGNORE_CASE
    )
    return token.findAll(area).mapNotNull { match ->
        val hours = match.groupValues[1].toIntOrNull() ?: 0
        val minutesWithHours = match.groupValues[2].toIntOrNull() ?: 0
        val secondsWithHours = match.groupValues[3].toIntOrNull() ?: 0
        val minutes = match.groupValues[4].toIntOrNull() ?: 0
        val secondsWithMinutes = match.groupValues[5].toIntOrNull() ?: 0
        val seconds = match.groupValues[6].toIntOrNull() ?: 0
        val total = hours * 3600 + minutesWithHours * 60 + secondsWithHours +
            minutes * 60 + secondsWithMinutes + seconds
        total.takeIf { it > 0 }
    }.lastOrNull()
}

private fun aliasesForResource(key: String): List<String> {
    val label = priceEntries.firstOrNull { it.key == key }?.label ?: key
    return when (key) {
        "oil" -> listOf("Öl", "Oel", "Ol")
        "rareEarth" -> listOf("Seltene Erden", "Seltene Erde")
        "titanium" -> listOf("Titan", "Titanium")
        "fuelRods" -> listOf("Brennstäbe", "Brennstaebe")
        "drillHeads" -> listOf("Bohrköpfe", "Bohrkoepfe")
        "garbageTruck" -> listOf("Müllwagen", "Muellwagen")
        "magnets" -> listOf("Magneten", "Magnete")
        else -> listOf(label)
    }
}

private fun canonicalOcr(value: String): String = value
    .lowercase(Locale.GERMANY)
    .replace("ä", "ae")
    .replace("ö", "oe")
    .replace("ü", "ue")
    .replace("ß", "ss")
    .filter { it.isLetterOrDigit() }

private fun loadFactoryUpgrade(
    prefs: SharedPreferences,
    index: Int,
    fallback: FactoryUpgrade
): FactoryUpgrade {
    val prefix = "factory_${index}_"
    if (!prefs.contains(prefix + "cost")) return fallback
    val inputs = prefs.getString(prefix + "inputs", null)
        ?.split(';')
        ?.mapNotNull { item ->
            val parts = item.split(':', limit = 2)
            if (parts.size != 2) null else parts[1].toDoubleOrNull()?.let { InputDelta(parts[0], it) }
        }
        ?: fallback.inputs

    return fallback.copy(
        fromLevel = prefs.getInt(prefix + "from", fallback.fromLevel),
        toLevel = prefs.getInt(prefix + "to", fallback.toLevel),
        cost = prefs.getLong(prefix + "cost", fallback.cost),
        durationSeconds = prefs.getInt(prefix + "duration", fallback.durationSeconds),
        outputDeltaPerStart = java.lang.Double.longBitsToDouble(
            prefs.getLong(prefix + "output_delta", fallback.outputDeltaPerStart.toBits())
        ),
        inputs = inputs,
        complete = prefs.getBoolean(prefix + "complete", fallback.complete)
    )
}

private fun saveFactoryUpgrade(
    editor: SharedPreferences.Editor,
    index: Int,
    upgrade: FactoryUpgrade
) {
    val prefix = "factory_${index}_"
    editor.putInt(prefix + "from", upgrade.fromLevel)
    editor.putInt(prefix + "to", upgrade.toLevel)
    editor.putLong(prefix + "cost", upgrade.cost)
    editor.putInt(prefix + "duration", upgrade.durationSeconds)
    editor.putLong(prefix + "output_delta", upgrade.outputDeltaPerStart.toBits())
    editor.putString(prefix + "inputs", upgrade.inputs.joinToString(";") { "${it.key}:${it.amountPerStart}" })
    editor.putBoolean(prefix + "complete", upgrade.complete)
}

private fun collectOcrBoxes(result: MlKitText): List<OcrBox> = buildList {
    result.textBlocks.forEach { block ->
        block.lines.forEach { line ->
            line.boundingBox?.let { box ->
                add(
                    OcrBox(
                        text = line.text,
                        left = box.left,
                        top = box.top,
                        right = box.right,
                        bottom = box.bottom,
                        granularity = 1
                    )
                )
            }
            line.elements.forEach { element ->
                element.boundingBox?.let { box ->
                    add(
                        OcrBox(
                            text = element.text,
                            left = box.left,
                            top = box.top,
                            right = box.right,
                            bottom = box.bottom,
                            granularity = 0
                        )
                    )
                }
            }
        }
    }
}

private fun findMineCostUpdatesFromText(text: String): Map<Int, Long> {
    val lines = text
        .replace('\u00A0', ' ')
        .lines()
        .map { it.replace(Regex("[ \\t]+"), " ").trim() }
        .filter { it.isNotBlank() }
    val numberPattern = Regex("[0-9]{1,3}(?:[.\\s][0-9]{3})+|[0-9]{6,12}")
    val aliasPatterns = mines.map { mine ->
        val aliases = mine.ocrAliases
            .sortedByDescending { it.length }
            .joinToString("|") { Regex.escape(it) }
        Regex(
            "(?<![\\p{L}\\p{N}])(?:$aliases)(?![\\p{L}\\p{N}])",
            RegexOption.IGNORE_CASE
        )
    }
    val result = mutableMapOf<Int, Long>()

    mines.indices.forEach { mineIndex ->
        val lineIndex = lines.indexOfFirst { aliasPatterns[mineIndex].containsMatchIn(it) }
        if (lineIndex < 0) return@forEach

        val candidateParts = mutableListOf<String>()
        for (offset in 0..2) {
            val currentIndex = lineIndex + offset
            if (currentIndex >= lines.size) break
            val line = lines[currentIndex]
            if (offset > 0 && aliasPatterns.indices.any { otherIndex ->
                    otherIndex != mineIndex && aliasPatterns[otherIndex].containsMatchIn(line)
                }) {
                break
            }
            candidateParts += if (offset == 0) {
                aliasPatterns[mineIndex].replaceFirst(line, " ")
            } else {
                line
            }
        }

        numberPattern.find(candidateParts.joinToString(" "))?.value?.let { raw ->
            parseLongGerman(raw)?.let { value ->
                if (value in 10_000L..9_999_999_999L) result[mineIndex] = value
            }
        }
    }
    return result
}

private fun parseLongGerman(value: String): Long? = value
    .trim()
    .replace(".", "")
    .replace(" ", "")
    .replace(",", "")
    .filter { it.isDigit() || it == '-' }
    .toLongOrNull()

private fun parseDoubleGerman(value: String): Double? {
    val raw = value.trim().replace(" ", "")
    val normalized = when {
        raw.contains(',') && raw.contains('.') -> raw.replace(".", "").replace(',', '.')
        raw.contains(',') -> raw.replace(',', '.')
        else -> raw
    }
    return normalized.toDoubleOrNull()
}

private fun formatIc(value: Long): String = NumberFormat.getIntegerInstance(Locale.GERMANY).format(value) + " IC"
private fun formatIc(value: Double): String = NumberFormat.getIntegerInstance(Locale.GERMANY).format(value) + " IC"
private fun formatAmount(value: Double): String = NumberFormat.getIntegerInstance(Locale.GERMANY).format(value)
private fun formatDuration(seconds: Int): String {
    if (seconds <= 0) return "unbekannte Dauer"
    val hours = seconds / 3600
    val minutes = (seconds % 3600) / 60
    val restSeconds = seconds % 60
    return buildList {
        if (hours > 0) add("${hours}h")
        if (minutes > 0) add("${minutes}m")
        if (restSeconds > 0) add("${restSeconds}s")
    }.joinToString(" ")
}
private fun formatDecimal(value: Double): String = String.format(Locale.GERMANY, "%.2f", value)
