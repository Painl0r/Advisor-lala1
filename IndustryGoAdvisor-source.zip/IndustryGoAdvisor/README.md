# Industry GO Berater – Android-App 0.1

Lokale Android-App für Painlor. Sie vergleicht neue Minen und die erfassten Fabrik-Upgrades nach zusätzlichem Gewinn pro Stunde und Amortisationszeit.

## Enthalten

- Alle im Chat erfassten Maximaloutputs der Minen.
- Minenbaupreise.
- Die 16 erfassten Fabrik-Upgrades.
- KI-Marktpreise als editierbare Startwerte.
- Marktsteuer, standardmäßig 11 %.
- Lokale Screenshot-Auswahl über den Android Photo Picker.
- Offline-OCR mit dem gebündelten ML-Kit-Modell.
- Automatische Übernahme von Kontostand, Marktsteuer und bekannten Marktpreisen, soweit eindeutig erkannt.
- Filter auf aktuell bezahlbare Projekte.

## Rechenannahmen

Die Minenoutputs sind Endwerte inklusive:

- 100 % Qualität
- 100 % Leben
- Optimierung 5.000/5.000 beziehungsweise ×5
- Kraftwerksbonus +40 %
- Verbundsbonus ×2

Die Boni werden nicht erneut multipliziert.

Der Diamantwert wurde von 3.691/h bei 99 % Qualität linear auf 3.728/h bei 100 % hochgerechnet.

## Einschränkungen der ersten Version

- Sondierungskosten und Strombedarf einzelner Neubauten fehlen, da diese Werte noch nicht vorliegen.
- Spielergebote werden noch nicht getrennt vom KI-Markt gespeichert.
- OCR kann Punkte und Kommas verwechseln. Übernommene Werte müssen kontrolliert werden.
- Das Projekt wurde in dieser Umgebung als Quellprojekt erzeugt, aber nicht auf einem Android-Gerät getestet.

## Öffnen und APK bauen

1. ZIP entpacken.
2. Ordner in Android Studio öffnen.
3. Gradle-Synchronisierung abwarten.
4. `Build > Build APK(s)` auswählen.
5. Die Debug-APK liegt anschließend normalerweise unter `app/build/outputs/apk/debug/app-debug.apk`.

Android Studio sollte JDK 17 für Gradle verwenden.
