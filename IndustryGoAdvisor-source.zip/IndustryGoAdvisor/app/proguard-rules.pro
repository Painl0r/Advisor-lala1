# Keine zusätzlichen Regeln für Version 0.1 erforderlich.
