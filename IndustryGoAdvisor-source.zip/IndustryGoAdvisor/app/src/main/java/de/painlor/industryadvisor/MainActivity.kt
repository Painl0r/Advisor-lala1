package de.painlor.industryadvisor

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ImageSearch
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.max

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                IndustryAdvisorApp(applicationContext)
            }
        }
    }
}

enum class ProjectType { MINE, FACTORY }

data class MineSpec(
    val name: String,
    val buildCost: Long,
    val maxOutputPerHour: Double,
    val productKey: String
)

data class InputDelta(val key: String, val amountPerStart: Double)

data class FactoryUpgrade(
    val name: String,
    val fromLevel: Int,
    val toLevel: Int,
    val cost: Long,
    val durationSeconds: Int,
    val outputKey: String,
    val outputDeltaPerStart: Double,
    val inputs: List<InputDelta>
)

data class Recommendation(
    val type: ProjectType,
    val name: String,
    val cost: Long,
    val profitPerHour: Double,
    val paybackHours: Double,
    val affordable: Boolean,
    val note: String = ""
)

data class PriceEntry(val key: String, val label: String, val defaultValue: Double)

private val priceEntries = listOf(
    PriceEntry("clay", "Lehm", 1.03),
    PriceEntry("stone", "Stein", 2.48),
    PriceEntry("iron", "Eisen", 6.23),
    PriceEntry("coal", "Kohle", 7.09),
    PriceEntry("copper", "Kupfer", 15.15),
    PriceEntry("oil", "Öl", 26.50),
    PriceEntry("silver", "Silber", 44.00),
    PriceEntry("gold", "Gold", 88.00),
    PriceEntry("titanium", "Titan", 144.00),
    PriceEntry("diamond", "Diamant", 280.00),
    PriceEntry("rareEarth", "Seltene Erden", 336.01),
    PriceEntry("uranium", "Uran", 480.00),
    PriceEntry("brick", "Ziegel", 14.00),
    PriceEntry("concrete", "Beton", 25.24),
    PriceEntry("steel", "Stahl", 95.84),
    PriceEntry("fuel", "Treibstoff", 65.49),
    PriceEntry("plastic", "Kunststoff", 38.50),
    PriceEntry("tools", "Werkzeuge", 69.92),
    PriceEntry("machine", "Maschine", 1193.67),
    PriceEntry("electronics", "Elektronik", 214.14),
    PriceEntry("cable", "Kabel", 66.96),
    PriceEntry("sensors", "Sensoren", 1006.30),
    PriceEntry("lubricant", "Schmierstoff", 37.28),
    PriceEntry("magnets", "Magneten", 427.19),
    PriceEntry("drillHeads", "Bohrköpfe", 1383.11),
    PriceEntry("fuelRods", "Brennstäbe", 1745.91),
    PriceEntry("helicopter", "Helikopter", 4087.27),
    PriceEntry("garbageTruck", "Müllwagen", 352.12)
)

private val mines = listOf(
    MineSpec("Lehmmine", 1_014_585, 19_453.0, "clay"),
    MineSpec("Steinmine", 226_260, 14_589.0, "stone"),
    MineSpec("Eisenmine", 4_317_615, 14_589.0, "iron"),
    MineSpec("Kohlemine", 6_267_660, 12_968.0, "coal"),
    MineSpec("Kupfermine", 2_257_560, 14_589.0, "copper"),
    MineSpec("Ölquelle", 3_320_160, 12_968.0, "oil"),
    MineSpec("Silbermine", 21_013_860, 8_916.0, "silver"),
    MineSpec("Goldmine", 25_824_960, 8_105.0, "gold"),
    MineSpec("Titanmine", 27_450_060, 6_484.0, "titanium"),
    MineSpec("Diamantmine", 60_900_000, 3_728.0, "diamond"),
    MineSpec("Mine für Seltene Erden", 183_230_640, 3_242.0, "rareEarth"),
    MineSpec("Uranmine", 315_906_735, 3_242.0, "uranium")
)

private val factoryUpgrades = listOf(
    FactoryUpgrade("Ziegelei", 78, 79, 19_644_374, 60, "brick", 514.0, listOf(InputDelta("clay", 1029.0))),
    FactoryUpgrade("Betonfabrik", 76, 77, 16_173_208, 90, "concrete", 343.0, listOf(InputDelta("stone", 687.0), InputDelta("clay", 343.0))),
    FactoryUpgrade("Stahlwerk", 100, 101, 416_908_018, 120, "steel", 1516.0, listOf(InputDelta("iron", 4548.0), InputDelta("coal", 3032.0))),
    FactoryUpgrade("Raffinerie", 84, 85, 35_201_746, 90, "fuel", 533.0, listOf(InputDelta("oil", 888.0))),
    FactoryUpgrade("Kabelfabrik", 92, 93, 76_618_249, 160, "cable", 1100.0, listOf(InputDelta("copper", 1467.0))),
    FactoryUpgrade("Kunststoffwerk", 54, 55, 1_905_172, 120, "plastic", 47.0, listOf(InputDelta("oil", 35.0), InputDelta("coal", 23.0))),
    FactoryUpgrade("Schmierstoffraffinerie", 58, 59, 2_810_724, 120, "lubricant", 50.0, listOf(InputDelta("oil", 67.0))),
    FactoryUpgrade("Werkzeugfabrik", 82, 83, 57_963_178, 180, "tools", 296.0, listOf(InputDelta("iron", 888.0), InputDelta("steel", 148.0))),
    FactoryUpgrade("Elektronikfabrik", 77, 78, 142_595_943, 240, "electronics", 188.0, listOf(InputDelta("copper", 564.0), InputDelta("silver", 188.0), InputDelta("gold", 94.0))),
    FactoryUpgrade("Sensorfabrik", 60, 61, 40_967_682, 300, "sensors", 20.0, listOf(InputDelta("electronics", 40.0), InputDelta("rareEarth", 20.0))),
    FactoryUpgrade("Magnetfabrik", 52, 53, 9_411_165, 300, "magnets", 20.0, listOf(InputDelta("iron", 78.0), InputDelta("rareEarth", 20.0))),
    FactoryUpgrade("Bohrkopffabrik", 93, 94, 1_688_819_434, 420, "drillHeads", 402.0, listOf(InputDelta("titanium", 1205.0), InputDelta("diamond", 402.0), InputDelta("steel", 803.0))),
    FactoryUpgrade("Maschinenfabrik", 86, 87, 213_784_498, 240, "machine", 213.0, listOf(InputDelta("steel", 851.0), InputDelta("cable", 851.0), InputDelta("fuel", 426.0))),
    FactoryUpgrade("Brennstäbe-Fabrik", 62, 63, 186_601_299, 480, "fuelRods", 24.0, listOf(InputDelta("uranium", 48.0), InputDelta("steel", 73.0))),
    FactoryUpgrade("Helikopterwerk", 19, 20, 3_804_962, 900, "helicopter", 0.0, listOf(InputDelta("steel", 3.0), InputDelta("machine", 1.0), InputDelta("cable", 2.0), InputDelta("fuel", 1.0))),
    FactoryUpgrade("Müllwagenwerk", 37, 38, 3_284_124, 600, "garbageTruck", 2.0, listOf(InputDelta("steel", 2.0), InputDelta("cable", 2.0), InputDelta("fuel", 2.0), InputDelta("lubricant", 2.0), InputDelta("tools", 2.0)))
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IndustryAdvisorApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("industry_go_advisor", Context.MODE_PRIVATE) }
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var cashText by rememberSaveable { mutableStateOf(prefs.getLong("cash", 46_705_712L).toString()) }
    var taxText by rememberSaveable { mutableStateOf(prefs.getFloat("tax", 11f).toString().replace('.', ',')) }
    var affordableOnly by rememberSaveable { mutableStateOf(true) }
    var ocrText by rememberSaveable { mutableStateOf("") }
    var ocrStatus by rememberSaveable { mutableStateOf("Noch kein Screenshot eingelesen.") }
    var isOcrRunning by remember { mutableStateOf(false) }

    val priceValues = remember {
        mutableStateListOf<Double>().apply {
            priceEntries.forEach { entry ->
                add(java.lang.Double.longBitsToDouble(prefs.getLong("price_${entry.key}", entry.defaultValue.toBits())))
            }
        }
    }

    fun saveSettings() {
        val cash = parseLongGerman(cashText) ?: 0L
        val tax = parseDoubleGerman(taxText) ?: 11.0
        prefs.edit().apply {
            putLong("cash", cash)
            putFloat("tax", tax.toFloat())
            priceEntries.forEachIndexed { index, entry -> putLong("price_${entry.key}", priceValues[index].toBits()) }
        }.apply()
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        isOcrRunning = true
        ocrStatus = "Texterkennung läuft …"
        val image = runCatching { InputImage.fromFilePath(context, uri) }.getOrElse {
            isOcrRunning = false
            ocrStatus = "Bild konnte nicht geöffnet werden: ${it.message}"
            return@rememberLauncherForActivityResult
        }
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(image)
            .addOnSuccessListener { result ->
                ocrText = result.text
                val parsed = applyOcrValues(result.text, cashText, taxText, priceValues)
                cashText = parsed.cashText
                taxText = parsed.taxText
                parsed.priceUpdates.forEach { (index, value) -> priceValues[index] = value }
                ocrStatus = parsed.message
                saveSettings()
            }
            .addOnFailureListener { error -> ocrStatus = "OCR-Fehler: ${error.message}" }
            .addOnCompleteListener {
                isOcrRunning = false
                recognizer.close()
            }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(title = { Text("Industry GO Berater") })
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Analytics, null) },
                    label = { Text("Analyse") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.ImageSearch, null) },
                    label = { Text("Screenshot") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Edit, null) },
                    label = { Text("Preise") }
                )
            }
        }
    ) { padding ->
        when (selectedTab) {
            0 -> AnalysisScreen(
                modifier = Modifier.padding(padding),
                cashText = cashText,
                onCashChange = { cashText = it; saveSettings() },
                taxText = taxText,
                onTaxChange = { taxText = it; saveSettings() },
                affordableOnly = affordableOnly,
                onAffordableOnlyChange = { affordableOnly = it },
                prices = priceEntries.mapIndexed { index, entry -> entry.key to priceValues[index] }.toMap()
            )
            1 -> ScreenshotScreen(
                modifier = Modifier.padding(padding),
                isRunning = isOcrRunning,
                status = ocrStatus,
                ocrText = ocrText,
                onPick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
            )
            else -> PricesScreen(
                modifier = Modifier.padding(padding),
                values = priceValues,
                onValueChange = { index, value ->
                    priceValues[index] = value
                    saveSettings()
                },
                onReset = {
                    priceEntries.forEachIndexed { index, entry -> priceValues[index] = entry.defaultValue }
                    saveSettings()
                }
            )
        }
    }
}

@Composable
private fun AnalysisScreen(
    modifier: Modifier,
    cashText: String,
    onCashChange: (String) -> Unit,
    taxText: String,
    onTaxChange: (String) -> Unit,
    affordableOnly: Boolean,
    onAffordableOnlyChange: (Boolean) -> Unit,
    prices: Map<String, Double>
) {
    val cash = parseLongGerman(cashText) ?: 0L
    val taxPercent = (parseDoubleGerman(taxText) ?: 11.0).coerceIn(0.0, 99.0)
    val recommendations = remember(cash, taxPercent, prices) {
        calculateRecommendations(cash, taxPercent, prices)
    }
    val visible = if (affordableOnly) recommendations.filter { it.affordable } else recommendations

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            OutlinedTextField(
                value = cashText,
                onValueChange = onCashChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Verfügbares IC") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        }
        item {
            OutlinedTextField(
                value = taxText,
                onValueChange = onTaxChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Marktsteuer in %") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("Nur aktuell bezahlbare Projekte", modifier = Modifier.weight(1f))
                Switch(checked = affordableOnly, onCheckedChange = onAffordableOnlyChange)
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Rechenmodus", fontWeight = FontWeight.Bold)
                    Text("Minen: 100 % Qualität, volle Optimierung ×5, Kraftwerk +40 % und Verbund ×2 sind bereits im Maximaloutput enthalten.")
                    Text("Preise: KI-Markt. Erlöse und Rohstoff-Opportunitätskosten werden um die Marktsteuer vermindert.")
                }
            }
        }
        if (visible.isEmpty()) {
            item { Text("Kein Projekt erfüllt den Filter.") }
        } else {
            items(visible) { rec -> RecommendationCard(rec) }
        }
    }
}

@Composable
private fun RecommendationCard(rec: Recommendation) {
    val nf = NumberFormat.getNumberInstance(Locale.GERMANY).apply { maximumFractionDigits = 1 }
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(rec.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(if (rec.type == ProjectType.MINE) "MINE" else "FABRIK")
            }
            Text("Kosten: ${formatIc(rec.cost)}")
            Text("Mehrgewinn: ${formatIc(rec.profitPerHour)} /h")
            if (rec.profitPerHour > 0.0 && rec.paybackHours.isFinite()) {
                val days = rec.paybackHours / 24.0
                Text("Amortisation: ${nf.format(rec.paybackHours)} h (${nf.format(days)} Tage)")
            } else {
                Text("Amortisation: nie – wirtschaftlich negativ", color = MaterialTheme.colorScheme.error)
            }
            Text(if (rec.affordable) "Jetzt bezahlbar" else "Noch nicht bezahlbar")
            if (rec.note.isNotBlank()) Text(rec.note)
        }
    }
}

@Composable
private fun ScreenshotScreen(
    modifier: Modifier,
    isRunning: Boolean,
    status: String,
    ocrText: String,
    onPick: () -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Button(onClick = onPick, enabled = !isRunning, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.ImageSearch, null)
                Spacer(Modifier.padding(4.dp))
                Text(if (isRunning) "Wird erkannt …" else "Industry-GO-Screenshot auswählen")
            }
        }
        item {
            Card {
                Column(Modifier.padding(14.dp)) {
                    Text("Status", fontWeight = FontWeight.Bold)
                    Text(status)
                }
            }
        }
        item {
            Text("Erkannter Text", fontWeight = FontWeight.Bold)
            Card(modifier = Modifier.fillMaxWidth()) {
                Text(
                    if (ocrText.isBlank()) "Noch keine OCR-Ausgabe." else ocrText,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
        item {
            Text("Die OCR übernimmt derzeit Kontostand, Handelskammer-Steuer und bekannte Marktpreise. Kontrolliere die Werte in Analyse und Preise, bevor du eine Empfehlung nutzt.")
        }
    }
}

@Composable
private fun PricesScreen(
    modifier: Modifier,
    values: List<Double>,
    onValueChange: (Int, Double) -> Unit,
    onReset: () -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Button(onClick = onReset, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Refresh, null)
                Spacer(Modifier.padding(4.dp))
                Text("KI-Preise zurücksetzen")
            }
        }
        items(priceEntries.indices.toList()) { index ->
            var text by remember(values[index]) { mutableStateOf(formatDecimal(values[index])) }
            OutlinedTextField(
                value = text,
                onValueChange = { input ->
                    text = input
                    parseDoubleGerman(input)?.let { if (it >= 0) onValueChange(index, it) }
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("${priceEntries[index].label} – IC/Stk") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
        }
    }
}

private fun calculateRecommendations(
    cash: Long,
    taxPercent: Double,
    prices: Map<String, Double>
): List<Recommendation> {
    val netFactor = 1.0 - taxPercent / 100.0
    val mineRecommendations = mines.map { mine ->
        val price = prices[mine.productKey] ?: 0.0
        val profit = mine.maxOutputPerHour * price * netFactor
        Recommendation(
            type = ProjectType.MINE,
            name = mine.name,
            cost = mine.buildCost,
            profitPerHour = profit,
            paybackHours = if (profit > 0) mine.buildCost / profit else Double.POSITIVE_INFINITY,
            affordable = cash >= mine.buildCost,
            note = "Idealoutput ${formatAmount(mine.maxOutputPerHour)}/h"
        )
    }

    val factoryRecommendations = factoryUpgrades.map { upgrade ->
        val startsPerHour = 3600.0 / upgrade.durationSeconds
        val grossOutput = upgrade.outputDeltaPerStart * startsPerHour * (prices[upgrade.outputKey] ?: 0.0)
        val grossInputs = upgrade.inputs.sumOf { input ->
            input.amountPerStart * startsPerHour * (prices[input.key] ?: 0.0)
        }
        val profit = (grossOutput - grossInputs) * netFactor
        Recommendation(
            type = ProjectType.FACTORY,
            name = "${upgrade.name} L${upgrade.fromLevel} → L${upgrade.toLevel}",
            cost = upgrade.cost,
            profitPerHour = profit,
            paybackHours = if (profit > 0) upgrade.cost / profit else Double.POSITIVE_INFINITY,
            affordable = cash >= upgrade.cost,
            note = if (upgrade.outputDeltaPerStart <= 0) "Kein zusätzlicher Output, aber höherer Verbrauch." else ""
        )
    }

    return (mineRecommendations + factoryRecommendations).sortedWith(
        compareBy<Recommendation> { if (it.profitPerHour > 0) it.paybackHours else Double.POSITIVE_INFINITY }
            .thenByDescending { it.profitPerHour }
    )
}

private data class OcrApplyResult(
    val cashText: String,
    val taxText: String,
    val priceUpdates: Map<Int, Double>,
    val message: String
)

private fun applyOcrValues(
    text: String,
    oldCash: String,
    oldTax: String,
    oldPrices: List<Double>
): OcrApplyResult {
    var cash = oldCash
    var tax = oldTax
    val updates = mutableMapOf<Int, Double>()
    val normalized = text.replace('\u00A0', ' ')

    Regex("Du hast\\s+([0-9.]+)", RegexOption.IGNORE_CASE).find(normalized)?.groupValues?.getOrNull(1)?.let {
        parseLongGerman(it)?.let { value -> cash = value.toString() }
    }
    if (cash == oldCash) {
        Regex("(?m)^([0-9]{1,3}(?:\\.[0-9]{3}){2,})\\s*(?:IC)?$").find(normalized)?.groupValues?.getOrNull(1)?.let {
            parseLongGerman(it)?.let { value -> cash = value.toString() }
        }
    }

    Regex("L11[^%]{0,40}(11)%", RegexOption.IGNORE_CASE).find(normalized)?.let { tax = "11" }
    Regex("Marktsteuer\\s*(?:ca\\.)?\\s*([0-9]{1,2})%", RegexOption.IGNORE_CASE).find(normalized)?.groupValues?.getOrNull(1)?.let { tax = it }

    priceEntries.forEachIndexed { index, entry ->
        val escaped = Regex.escape(entry.label)
        val pattern = Regex("$escaped[\\s\\S]{0,90}?([0-9]{1,4}(?:[.,][0-9]{1,2})?)\\s*(?:IC)?\\s*/?Stk", RegexOption.IGNORE_CASE)
        pattern.find(normalized)?.groupValues?.getOrNull(1)?.let { raw ->
            parseDoubleGerman(raw)?.let { value ->
                if (value > 0) updates[index] = value
            }
        }
    }

    val parts = mutableListOf<String>()
    if (cash != oldCash) parts += "Kontostand übernommen"
    if (tax != oldTax) parts += "Marktsteuer übernommen"
    if (updates.isNotEmpty()) parts += "${updates.size} Marktpreis(e) übernommen"
    val message = if (parts.isEmpty()) {
        "Text erkannt, aber keine sicheren Werte automatisch übernommen. Bitte OCR-Text und Eingaben kontrollieren."
    } else {
        parts.joinToString(" · ") + ". Bitte kontrollieren."
    }
    return OcrApplyResult(cash, tax, updates, message)
}

private fun parseLongGerman(value: String): Long? = value
    .trim()
    .replace(".", "")
    .replace(" ", "")
    .replace(",", "")
    .filter { it.isDigit() || it == '-' }
    .toLongOrNull()

private fun parseDoubleGerman(value: String): Double? {
    val raw = value.trim().replace(" ", "")
    val normalized = when {
        raw.contains(',') && raw.contains('.') -> raw.replace(".", "").replace(',', '.')
        raw.contains(',') -> raw.replace(',', '.')
        else -> raw
    }
    return normalized.toDoubleOrNull()
}

private fun formatIc(value: Long): String = NumberFormat.getIntegerInstance(Locale.GERMANY).format(value) + " IC"
private fun formatIc(value: Double): String = NumberFormat.getIntegerInstance(Locale.GERMANY).format(value) + " IC"
private fun formatAmount(value: Double): String = NumberFormat.getIntegerInstance(Locale.GERMANY).format(value)
private fun formatDecimal(value: Double): String = String.format(Locale.GERMANY, "%.2f", value)
